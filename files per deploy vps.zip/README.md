# File di deploy — gestionale-hotel
Preparati il 15/07/2026, in attesa di conferma costi dal titolare.
Da adattare e usare quando si esegue il Modulo 1.10 (vedi CLAUDE.md).

## Contenuto

| File | Cosa fa | Dove va |
|---|---|---|
| `ecosystem.config.js` | Avvia backend + frontend con PM2 | Root del progetto sul VPS |
| `env.production.example` | Template variabili ambiente | Rinominare in `.env.production`, compilare, NON committare |
| `nginx-gestionale.conf` | Reverse proxy + routing SSE | `/etc/nginx/sites-available/gestionale` sul VPS |
| `backup-db.sh` | Backup notturno DB su Backblaze B2 | Es. `~/scripts/backup-db.sh` sul VPS, poi in crontab |

## Cosa manca (da verificare con la repo reale, non ipotizzabile da qui)

- Percorsi esatti `cwd`/`script` in `ecosystem.config.js` (nomi cartelle backend/frontend, entry point Express)
- Nome effettivo del sottodominio da usare per il gestionale (es. `gestionale.hoteldelgolfolerici.com` — da confermare, dipende anche da quando torna disponibile il dominio principale dall'agenzia)
- Elenco completo dei path SSE da escludere dal buffering Nginx (ho messo sala/cucina/ristorante in base a quanto discusso, ma va confermato contro il codice reale)

## Checklist rapida per la sessione di deploy con Claude Code

1. Copiare questi file nella repo (o passarli come riferimento)
2. Far confermare a Claude Code i percorsi reali e correggere i TODO
3. Compilare `.env.production` con le credenziali vere (mai a mano su file condivisi — direttamente sul VPS)
4. Eseguire Modulo 1.10 come da CLAUDE.md
5. Alla fine: test di ripristino di un backup, come discusso
