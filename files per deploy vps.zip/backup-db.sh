#!/bin/bash
# Backup notturno DB gestionale-hotel -> Backblaze B2
# Setup richiesto prima del primo uso:
#   1. Creare bucket privato su Backblaze B2 (es. gestionale-hotel-backup)
#   2. Installare rclone: curl https://rclone.org/install.sh | sudo bash
#   3. Configurare rclone: rclone config (nome remote: "b2", tipo: b2)
#   4. chmod +x backup-db.sh
#   5. Aggiungere a crontab: 0 3 * * * /percorso/backup-db.sh >> /percorso/logs/backup.log 2>&1

set -e

DB_NAME="gestionale_hotel"
DB_USER="gestionale_user"
BACKUP_DIR="$HOME/backups"
B2_REMOTE="b2:gestionale-hotel-backup"
DATE=$(date +%Y%m%d_%H%M%S)
FILENAME="gestionale_${DATE}.sql.gz"

mkdir -p "$BACKUP_DIR"

echo "[$(date)] Avvio backup $DB_NAME..."

pg_dump -U "$DB_USER" "$DB_NAME" | gzip > "$BACKUP_DIR/$FILENAME"

echo "[$(date)] Dump creato: $FILENAME ($(du -h "$BACKUP_DIR/$FILENAME" | cut -f1))"

rclone copy "$BACKUP_DIR/$FILENAME" "$B2_REMOTE"

echo "[$(date)] Upload su B2 completato."

# Pulizia: mantiene solo gli ultimi 7 giorni di dump locali (su B2 restano tutti)
find "$BACKUP_DIR" -name "*.sql.gz" -mtime +7 -delete

echo "[$(date)] Backup completato: $FILENAME"
