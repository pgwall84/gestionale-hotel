// PM2 ecosystem file — gestionale-hotel
// Adattare "cwd" e "script" ai percorsi reali della repo prima dell'uso.
// Avvio: pm2 start ecosystem.config.js
// Persistenza al riavvio: pm2 save && pm2 startup

module.exports = {
  apps: [
    {
      name: 'gestionale-backend',
      cwd: './backend',           // TODO: verificare percorso cartella backend nella repo
      script: 'server.js',        // TODO: verificare nome file entry point Express
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        PORT: 7001
      },
      max_memory_restart: '300M',
      error_file: '../logs/backend-error.log',
      out_file: '../logs/backend-out.log',
      time: true,
      autorestart: true,
      watch: false
    },
    {
      name: 'gestionale-frontend',
      cwd: './frontend',          // TODO: verificare percorso cartella frontend nella repo
      script: 'node_modules/.bin/next',
      args: 'start -p 7000',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        PORT: 7000
      },
      max_memory_restart: '300M',
      error_file: '../logs/frontend-error.log',
      out_file: '../logs/frontend-out.log',
      time: true,
      autorestart: true,
      watch: false
    }
  ]
};
